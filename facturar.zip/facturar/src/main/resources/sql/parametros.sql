INSERT INTO public.parametros (id, created_at, deleted, enabled, last_update_at, atributo, codigo, entidad, valor) VALUES(2, '2022-01-01', false, true, null, 'tipo_usuario', 1001, 'usuario', 'Cliente');
INSERT INTO public.parametros (id, created_at, deleted, enabled, last_update_at, atributo, codigo, entidad, valor) VALUES(3, '2022-01-01', false, true, null, 'tipo_usuario', 1002, 'usuario', 'Proveedor');

INSERT INTO public.parametros (id, created_at, deleted, enabled, last_update_at, atributo, codigo, entidad, valor) VALUES(4, '2022-01-01', false, true, null, 'tipo_documento', 1010, 'Cédula de Ciudadanía', 'Cédula de Ciudadanía');
INSERT INTO public.parametros (id, created_at, deleted, enabled, last_update_at, atributo, codigo, entidad, valor) VALUES(5, '2022-01-01', false, true, null, 'tipo_documento', 1011, 'Cédula de Extranjería', 'Cédula de Extranjería');
INSERT INTO public.parametros (id, created_at, deleted, enabled, last_update_at, atributo, codigo, entidad, valor) VALUES(6, '2022-01-01', false, true, null, 'tipo_documento', 1012, 'Pasaporte', 'Pasaporte');

INSERT INTO public.parametros (id, created_at, deleted, enabled, last_update_at, atributo, codigo, entidad, valor) VALUES(7, '2022-01-01', false, true, null, 'estado', 1030, 'true', 'Activo');
INSERT INTO public.parametros (id, created_at, deleted, enabled, last_update_at, atributo, codigo, entidad, valor) VALUES(8, '2022-01-01', false, true, null, 'estado', 1031, 'false', 'Inactivo');



