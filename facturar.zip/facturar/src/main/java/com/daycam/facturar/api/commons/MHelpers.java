package com.daycam.facturar.api.commons;

import org.modelmapper.ModelMapper;

public class MHelpers {

	public static ModelMapper modelMapper() {

		return new ModelMapper();
	}

}
