package com.daycam.facturar.api.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.daycam.facturar.api.dto.UsuarioDto;
import com.daycam.facturar.api.entities.Usuario;


@Service
public interface UsuarioService {
	
	Usuario save(UsuarioDto usuarioDto);
	
	List<UsuarioDto> findUsuarios();
}
